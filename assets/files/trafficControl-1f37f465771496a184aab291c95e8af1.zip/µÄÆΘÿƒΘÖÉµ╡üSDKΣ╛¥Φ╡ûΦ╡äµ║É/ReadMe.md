## 使用说明
游戏接入限流 SDK 时，需要将 `drawable-hdpi` 目录里的资源文件合并到项目对应目录中（一般为 Assets/Plugins/Android/res/drawable-hdpi)
